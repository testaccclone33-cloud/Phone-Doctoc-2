# Phone Doctor 2.0 — Android Native

Ứng dụng chẩn đoán thiết bị Android giao diện tối giản Premium. Dự án dùng Java + Android SDK, không kéo thư viện bên thứ ba và không cần Internet khi chạy.

## Chức năng đã có

- Tổng quan: hãng / model, Android / API, ABI, số lõi CPU khả dụng, độ phân giải / tần số quét, RAM, bộ nhớ trong, trạng thái pin, nhiệt pin, mức nhiệt hệ thống, kết nối và số cảm biến.
- Chỉ số tình trạng ước tính từ dung lượng trống, RAM khả dụng và cảnh báo pin / nhiệt. Đây không phải điểm sức khỏe do hãng sản xuất cung cấp.
- Màn hình: lần lượt hiển thị đen, trắng, đỏ, xanh lá, xanh dương và xám để người dùng quan sát điểm chết / điểm sáng / sai màu.
- Cảm ứng: kiểm tra rê ngón tay và số điểm chạm đồng thời Android báo nhận được.
- Âm thanh: phát âm thử riêng kênh trái / phải; đo biên độ micro 2 giây sau khi người dùng chủ động bấm và cấp quyền. Không lưu bản ghi.
- Cảm biến: liệt kê cảm biến Android cung cấp và giá trị trực tiếp khi thiết bị thay đổi.
- Đèn flash: bật / tắt thủ công sau khi người dùng cấp quyền CAMERA; không chụp ảnh.
- Rung: một nhịp ngắn 280 ms.
- Camera: mở giao diện camera mặc định của Android để người dùng tự kiểm tra camera trước / sau; Phone Doctor không chụp hoặc lưu ảnh.
- GPU: hoạt cảnh Canvas 2D trong 4 giây và ước lượng FPS render.
- CPU: phép thử số nguyên tố trong 2 giây (chỉ hữu ích để so sánh các lần chạy trên cùng máy).
- Bảo trì: xóa cache riêng của Phone Doctor; mở trang quản lý bộ nhớ Android; xuất báo cáo văn bản để chia sẻ.

## Tương thích

- `minSdk 23` (Android 6.0), kiểm thử mục tiêu tương thích với Android 10 trở lên.
- `compileSdk 35`, `targetSdk 34`.
- Không có quyền Internet, vị trí, danh bạ, ảnh / video, SMS, cuộc gọi hoặc quyền truy cập toàn bộ tệp.

## Build APK bằng GitHub Actions

1. Tạo repository GitHub mới và tải toàn bộ nội dung thư mục dự án này lên (giữ nguyên thư mục `.github/workflows`).
2. Mở tab **Actions** của repository. Cho phép Actions nếu GitHub hỏi.
3. Chạy workflow **Build Phone Doctor APK** bằng nút **Run workflow**, hoặc đẩy commit lên nhánh `main` / `master`.
4. Khi workflow báo thành công, mở lần chạy đó, kéo xuống **Artifacts**, tải `Phone-Doctor-2.0-debug-APK` và giải nén để lấy `app-debug.apk`.
5. Chuyển APK sang điện thoại, mở tệp và cho phép cài ứng dụng từ nguồn đó khi Android yêu cầu.

Build local cần JDK 17, Gradle 8.9 và Android SDK Platform 35 + Build Tools 35.0.0. Lệnh từ thư mục dự án: `gradle assembleDebug`. APK nằm tại `app/build/outputs/apk/debug/app-debug.apk`.

## Giới hạn kỹ thuật Android (nói rõ, không giả lập)

- Ứng dụng Android thông thường không được đọc tùy ý dung lượng pin thiết kế / chu kỳ sạc / phần trăm chai pin chính xác trên mọi hãng. Ứng dụng chỉ hiển thị dữ liệu hệ thống thực sự cung cấp như mức pin, nhiệt độ, điện áp, trạng thái sức khỏe do Android báo.
- Không thể tự động kết luận điểm chết màn hình bằng API công khai; bài test màu yêu cầu mắt người dùng quan sát.
- FPS Canvas không phải benchmark GPU Vulkan / OpenGL chuyên dụng và không so sánh trực tiếp với điểm benchmark thương mại.
- RAM khả dụng là số liệu hệ thống tại thời điểm quét; app không thể đọc RAM riêng của từng ứng dụng khác.
- Không thể xóa cache / dữ liệu của ứng dụng khác, ép dừng ứng dụng khác hoặc “tăng tốc RAM” một cách an toàn bằng app thường. Android tự quản lý tiến trình. Nút dọn dẹp chỉ xóa cache riêng của Phone Doctor.
- Không tự bật micro, camera, đèn flash hoặc rung khi mở app. Người dùng phải mở đúng bài test và chủ động cấp quyền / thao tác.
- Một số hãng không cung cấp đầy đủ cảm biến, dữ liệu nhiệt hoặc quyền điều khiển đèn flash; kết quả sẽ hiện N/A hoặc thông báo lỗi thay vì đoán.

## Quyền riêng tư

Dữ liệu được đọc cục bộ. Không có thư viện quảng cáo / phân tích, không gửi dữ liệu lên máy chủ. Micro chỉ đọc mẫu âm thanh trong RAM trong thời gian thử và không tạo tệp ghi âm. Camera permission chỉ dùng để bật đèn flash qua CameraManager.
