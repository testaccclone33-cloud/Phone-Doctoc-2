package com.phonedoctor.premium;

import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PointF;
import android.os.Bundle;
import android.util.SparseArray;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;

public class TouchTestActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(new TouchCanvas(this));
    }
    private static class TouchCanvas extends View {
        private final Paint paint = new Paint(3);
        private final SparseArray<PointF> points = new SparseArray<>();
        private int max = 0;
        private int live = 0;
        TouchCanvas(Activity c) { super(c); setBackgroundColor(Color.rgb(9,14,21)); }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            paint.setColor(Color.WHITE); paint.setTextSize(20); paint.setFakeBoldText(true);
            c.drawText("KIỂM TRA CẢM ỨNG", 24, 55, paint);
            paint.setFakeBoldText(false); paint.setTextSize(14); paint.setColor(0xFF91A2B0);
            c.drawText("Đặt nhiều ngón tay và rê khắp màn hình", 24, 82, paint);
            paint.setColor(0xFF76E6C4); paint.setTextSize(16);
            c.drawText("Đang chạm: " + live + "    •    Tối đa ghi nhận: " + max, 24, 115, paint);
            for (int i=0;i<points.size();i++) {
                PointF p=points.valueAt(i);
                paint.setColor(0x5576E6C4); c.drawCircle(p.x,p.y,42,paint);
                paint.setColor(0xFF76E6C4); paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(3); c.drawCircle(p.x,p.y,42,paint); paint.setStyle(Paint.Style.FILL);
                paint.setColor(Color.WHITE); paint.setTextSize(12); c.drawText("ID "+points.keyAt(i),p.x-10,p.y+4,paint);
            }
        }
        @Override public boolean onTouchEvent(MotionEvent e) {
            int action=e.getActionMasked();
            if (action==MotionEvent.ACTION_DOWN || action==MotionEvent.ACTION_POINTER_DOWN || action==MotionEvent.ACTION_MOVE) {
                for (int i=0;i<e.getPointerCount();i++) points.put(e.getPointerId(i),new PointF(e.getX(i),e.getY(i)));
            } else if (action==MotionEvent.ACTION_UP || action==MotionEvent.ACTION_POINTER_UP || action==MotionEvent.ACTION_CANCEL) {
                int idx=e.getActionIndex(); if (idx<e.getPointerCount()) points.remove(e.getPointerId(idx));
                if (action==MotionEvent.ACTION_CANCEL) points.clear();
            }
            live=points.size(); max=Math.max(max,live); invalidate(); return true;
        }
    }
}
