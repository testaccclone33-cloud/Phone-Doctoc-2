package com.phonedoctor.premium;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.TextView;

public class ScreenTestActivity extends Activity {
    private final int[] colors = {Color.BLACK, Color.WHITE, Color.RED, Color.GREEN, Color.BLUE, Color.rgb(128,128,128), Color.rgb(24,24,24)};
    private final String[] names = {"ĐEN", "TRẮNG", "ĐỎ", "XANH LÁ", "XANH DƯƠNG", "XÁM", "XÁM ĐẬM"};
    private int index = 0;
    private FrameLayout root;
    private TextView label;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        root = new FrameLayout(this);
        label = new TextView(this);
        label.setTextColor(Color.WHITE); label.setTextSize(14); label.setGravity(Gravity.CENTER);
        label.setPadding(18, 14, 18, 14);
        label.setBackgroundColor(0x99000000);
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(-1, -2, Gravity.TOP);
        root.addView(label, p);
        root.setOnClickListener(v -> nextColor());
        label.setOnClickListener(v -> nextColor());
        setContentView(root);
        showColor();
    }
    private void nextColor() { index++; if (index >= colors.length) { finish(); return; } showColor(); }
    private void showColor() {
        root.setBackgroundColor(colors[index]);
        label.setText("KIỂM TRA MÀN HÌNH  •  " + (index+1) + "/" + colors.length + "\n" + names[index] + "  —  chạm để chuyển màu\nTìm chấm sáng / tối / điểm ảnh lệch màu. Nhấn Back để thoát.");
        label.setTextColor(index == 1 ? Color.BLACK : Color.WHITE);
        label.setBackgroundColor(index == 1 ? 0x99FFFFFF : 0x99000000);
    }
}
