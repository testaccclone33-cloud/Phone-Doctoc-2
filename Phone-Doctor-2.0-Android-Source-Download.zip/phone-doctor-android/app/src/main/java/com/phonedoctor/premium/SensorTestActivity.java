package com.phonedoctor.premium;

import android.app.Activity;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class SensorTestActivity extends Activity implements SensorEventListener {
    private SensorManager manager;
    private TextView output;
    private final Map<Integer,String> values = new HashMap<>();
    private long lastUpdate=0;
    private List<Sensor> sensors;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        manager=(SensorManager)getSystemService(SENSOR_SERVICE);
        sensors=manager.getSensorList(Sensor.TYPE_ALL);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(20,22,20,20); root.setBackgroundColor(Color.rgb(9,14,21));
        TextView title=new TextView(this); title.setText("CẢM BIẾN THIẾT BỊ"); title.setTextColor(Color.WHITE); title.setTextSize(20); title.setTypeface(null,1); root.addView(title);
        TextView hint=new TextView(this); hint.setText("Đặt máy nằm yên, sau đó nghiêng / xoay nhẹ để xem giá trị thay đổi."); hint.setTextColor(0xFF91A2B0); hint.setTextSize(12); hint.setPadding(0,8,0,16); root.addView(hint);
        ScrollView scroll=new ScrollView(this); output=new TextView(this); output.setTextColor(0xFF76E6C4); output.setTextSize(13); output.setLineSpacing(8,1f); scroll.addView(output); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root); render();
    }
    @Override protected void onResume() { super.onResume(); if(manager!=null && sensors!=null) for(Sensor s:sensors) manager.registerListener(this,s,SensorManager.SENSOR_DELAY_UI); }
    @Override protected void onPause() { if(manager!=null) manager.unregisterListener(this); super.onPause(); }
    @Override public void onSensorChanged(SensorEvent e) {
        StringBuilder v=new StringBuilder();
        for(int i=0;i<e.values.length;i++){ if(i>0)v.append(", "); v.append(String.format(Locale.US,"%.3f",e.values[i])); }
        values.put(e.sensor.getType(),v.toString());
        long now=System.currentTimeMillis(); if(now-lastUpdate>350){lastUpdate=now;render();}
    }
    @Override public void onAccuracyChanged(Sensor s,int accuracy) {}
    private void render() {
        if(output==null || sensors==null)return;
        StringBuilder b=new StringBuilder(); b.append("TỔNG QUAN: ").append(sensors.size()).append(" cảm biến được liệt kê\n\n");
        for(Sensor s:sensors){
            b.append("• ").append(s.getName()).append("\n  ").append(sensorType(s.getType())).append("\n  ");
            b.append(values.containsKey(s.getType())?values.get(s.getType()):"Chờ dữ liệu…");
            b.append("\n  Hãng: ").append(s.getVendor()).append("\n\n");
        }
        output.setText(b.toString());
    }
    private String sensorType(int t){
        switch(t){case Sensor.TYPE_ACCELEROMETER:return "Gia tốc";case Sensor.TYPE_GYROSCOPE:return "Con quay hồi chuyển";case Sensor.TYPE_MAGNETIC_FIELD:return "Từ trường / la bàn";case Sensor.TYPE_PROXIMITY:return "Tiệm cận";case Sensor.TYPE_LIGHT:return "Ánh sáng";case Sensor.TYPE_PRESSURE:return "Áp suất";case Sensor.TYPE_STEP_COUNTER:return "Đếm bước";case Sensor.TYPE_STEP_DETECTOR:return "Phát hiện bước";case Sensor.TYPE_GRAVITY:return "Trọng lực";case Sensor.TYPE_ROTATION_VECTOR:return "Vector xoay";default:return "Loại cảm biến #"+t;}
    }
}
