package com.phonedoctor.premium;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.pm.PackageManager;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class AudioTestActivity extends Activity {
    private static final int MIC_REQ=31;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private TextView status;
    private volatile AudioTrack activeTrack;
    private volatile boolean recording=false;
    @Override public void onCreate(Bundle b){
        super.onCreate(b); getWindow().setStatusBarColor(Color.rgb(9,14,21)); getWindow().setNavigationBarColor(Color.rgb(9,14,21));
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(22,24,22,20); root.setBackgroundColor(Color.rgb(9,14,21));
        TextView title=txt("KIỂM TRA ÂM THANH",22,Color.WHITE,true); root.addView(title);
        TextView desc=txt("Dùng âm lượng vừa phải. Nếu máy có loa kép, bạn sẽ nghe thử từng kênh; một số điện thoại có thể tự trộn âm thanh stereo.",13,0xFF91A2B0,false); desc.setPadding(0,10,0,20); root.addView(desc);
        root.addView(button("Phát âm thử loa TRÁI",()->playTone(true)));
        root.addView(button("Phát âm thử loa PHẢI",()->playTone(false)));
        TextView micTitle=txt("MICROPHONE",12,0xFF76E6C4,true); micTitle.setPadding(0,25,0,6); root.addView(micTitle);
        root.addView(txt("Chỉ đo mức âm trong khoảng 2 giây. Âm thanh không được lưu thành tệp.",12,0xFF91A2B0,false));
        Button mic=button("KIỂM TRA MICRO",this::startMicCheck); mic.setTextColor(Color.rgb(9,14,21)); mic.setBackground(round(0xFF76E6C4,16)); root.addView(mic);
        status=txt("Sẵn sàng. Hãy bấm từng bài test để thực hiện.",13,Color.WHITE,false); status.setPadding(15,15,15,15); status.setBackground(round(0xFF111B26,16)); LinearLayout.LayoutParams slp=new LinearLayout.LayoutParams(-1,-2); slp.topMargin=18; root.addView(status,slp);
        setContentView(root);
    }
    private void playTone(boolean left){
        status.setText(left?"Đang phát thử kênh trái…":"Đang phát thử kênh phải…");
        new Thread(()->{
            AudioTrack track=null;
            try{
                int sr=44100, frames=sr, freq=660; short[] data=new short[frames*2];
                for(int i=0;i<frames;i++){
                    short sample=(short)(Math.sin(2*Math.PI*freq*i/sr)*6500);
                    data[i*2]=left?sample:0; data[i*2+1]=left?0:sample;
                }
                track=new AudioTrack(AudioManager.STREAM_MUSIC,sr,AudioFormat.CHANNEL_OUT_STEREO,AudioFormat.ENCODING_PCM_16BIT,data.length*2,AudioTrack.MODE_STATIC);
                activeTrack=track; track.write(data,0,data.length); track.play();
                AudioTrack finalTrack=track;
                handler.postDelayed(()->{try{if(finalTrack.getPlayState()==AudioTrack.PLAYSTATE_PLAYING)finalTrack.stop();}catch(Exception ignored){} try{finalTrack.release();}catch(Exception ignored){} if(activeTrack==finalTrack)activeTrack=null; status.setText("Đã phát xong. Nếu không nghe thấy, tăng âm lượng media và thử lại.");},1100);
            }catch(Exception e){if(track!=null)try{track.release();}catch(Exception ignored){} handler.post(()->status.setText("Không phát được âm thử: "+e.getClass().getSimpleName()));}
        }).start();
    }
    private void startMicCheck(){
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){
            new AlertDialog.Builder(this).setTitle("Cho phép dùng micro?").setMessage("Phone Doctor sẽ đo âm lượng đầu vào trong khoảng 2 giây để kiểm tra micro. Không ghi âm thành tệp và không gửi dữ liệu.")
                    .setNegativeButton("Hủy",null).setPositiveButton("Tiếp tục",(d,w)->requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},MIC_REQ)).show();
        }else runMicCheck();
    }
    @Override public void onRequestPermissionsResult(int req,String[] perms,int[] results){super.onRequestPermissionsResult(req,perms,results); if(req==MIC_REQ){if(results.length>0 && results[0]==PackageManager.PERMISSION_GRANTED)runMicCheck();else status.setText("Chưa được cấp quyền micro. Bạn có thể cấp lại trong Cài đặt ứng dụng.");}}
    private void runMicCheck(){
        if(recording)return; recording=true; status.setText("Đang đo micro trong 2 giây… Hãy nói gần điện thoại.");
        new Thread(()->{
            AudioRecord rec=null;
            try{
                int sr=16000; int min=AudioRecord.getMinBufferSize(sr,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT);
                if(min<=0)throw new IllegalStateException("Micro không hỗ trợ cấu hình đo");
                rec=new AudioRecord(MediaRecorder.AudioSource.MIC,sr,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT,Math.max(min,4096));
                short[] buffer=new short[Math.max(1024,min/2)]; long sum=0; long count=0; int peak=0;
                rec.startRecording(); long until=SystemClock.elapsedRealtime()+2000;
                while(SystemClock.elapsedRealtime()<until){int n=rec.read(buffer,0,buffer.length); if(n>0)for(int i=0;i<n;i++){int v=Math.abs((int)buffer[i]);peak=Math.max(peak,v);sum+=(long)v*v;count++;}}
                rec.stop(); final int p=peak; final double rms=count>0?Math.sqrt(sum/(double)count):0;
                handler.post(()->status.setText("Đo xong • RMS " + String.format(Locale.US,"%.0f",rms) + " / 32767 • Đỉnh " + p + "\n" + (p>300?"Micro có ghi nhận tín hiệu âm thanh.":"Tín hiệu thấp: thử nói gần micro, kiểm tra lỗ micro và quyền ứng dụng.")));
            }catch(Exception e){handler.post(()->status.setText("Không đo được micro: "+e.getMessage()));}
            finally{if(rec!=null)try{rec.release();}catch(Exception ignored){} recording=false;}
        }).start();
    }
    @Override protected void onDestroy(){handler.removeCallbacksAndMessages(null); AudioTrack t=activeTrack;if(t!=null){try{t.stop();}catch(Exception ignored){}try{t.release();}catch(Exception ignored){}} super.onDestroy();}
    private Button button(String label,Runnable r){Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextSize(13);b.setTextColor(Color.WHITE);b.setBackground(round(0xFF16232F,16));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,54);lp.bottomMargin=10;b.setOnClickListener(v->r.run());b.setLayoutParams(lp);return b;}
    private TextView txt(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,1);return t;}
    private GradientDrawable round(int c,int r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(r*getResources().getDisplayMetrics().density);return d;}
}
