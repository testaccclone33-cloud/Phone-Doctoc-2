package com.phonedoctor.premium;

import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.view.WindowManager;

import java.util.Locale;

public class GpuTestActivity extends Activity {
    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);setContentView(new BenchView(this));}
    private static class BenchView extends View {
        private final Paint p=new Paint(3);
        private long start=0,finish=0;
        private int frames=0;
        private boolean running=true;
        private float fps=0;
        BenchView(Activity a){super(a);setBackgroundColor(Color.rgb(9,14,21));}
        @Override protected void onDraw(Canvas c){
            super.onDraw(c);
            long now=SystemClock.elapsedRealtime(); if(start==0)start=now;
            if(running){frames++;long elapsed=now-start;if(elapsed>=4000){running=false;finish=now;fps=frames*1000f/Math.max(1,elapsed);} }
            float w=getWidth(),h=getHeight(),cx=w/2f,cy=h/2f;
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);p.setColor(0xFF294457);
            for(int i=0;i<5;i++)c.drawCircle(cx,cy,42+i*34,p);
            p.setStyle(Paint.Style.FILL);
            for(int i=0;i<22;i++){
                double a=(now-start)*0.001*(0.7+i*0.025)+i*0.7;
                float r=52+(i%5)*30;
                float x=cx+(float)Math.cos(a)*r, y=cy+(float)Math.sin(a)*r;
                p.setColor(i%2==0?0xFF76E6C4:0xFF73B2FF);c.drawCircle(x,y,5+(i%4)*2,p);
            }
            p.setTextAlign(Paint.Align.CENTER);p.setColor(Color.WHITE);p.setTextSize(20);p.setFakeBoldText(true);c.drawText("GPU / KHUNG HÌNH",cx,Math.max(60,cy-170),p);
            p.setFakeBoldText(false);p.setTextSize(14);p.setColor(0xFF91A2B0);c.drawText(running?"Đang dựng hoạt cảnh…":"Đã hoàn tất phép đo",cx,Math.max(86,cy-140),p);
            p.setColor(0xFF76E6C4);p.setTextSize(30);c.drawText(running?String.format(Locale.US,"%.1f s",(now-start)/1000f):String.format(Locale.US,"%.1f FPS",fps),cx,cy+205,p);
            p.setTextSize(12);p.setColor(0xFF91A2B0);c.drawText(running?"Đo trong 4 giây • giữ máy ở màn hình này":"FPS trung bình của hoạt cảnh Canvas 2D",cx,cy+232,p);
            p.setTextAlign(Paint.Align.LEFT);
            if(running)postInvalidateOnAnimation();
        }
        @Override protected void onDetachedFromWindow(){running=false;super.onDetachedFromWindow();}
    }
}
