package com.phonedoctor.premium;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.StatFs;
import android.os.Vibrator;
import android.os.VibrationEffect;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.text.DecimalFormat;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(9, 14, 21);
    private static final int PANEL = Color.rgb(17, 27, 38);
    private static final int PANEL_2 = Color.rgb(22, 35, 47);
    private static final int TEXT = Color.rgb(237, 244, 248);
    private static final int MUTED = Color.rgb(145, 162, 176);
    private static final int MINT = Color.rgb(118, 230, 196);
    private static final int BLUE = Color.rgb(115, 178, 255);
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private TextView scoreValue, scoreNote, deviceSummary, statusLine, ramValue, storageValue, batteryValue, thermalValue, adviceValue;
    private ProgressBar healthBar;
    private DeviceSnapshot snapshot;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);
        buildUi();
        refreshSnapshot();
    }

    @Override protected void onResume() {
        super.onResume();
        if (scoreValue != null) refreshSnapshot();
    }

    @Override protected void onDestroy() {
        worker.shutdownNow();
        super.onDestroy();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(20), dp(18), dp(20), dp(30));
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("PHONE DOCTOR", 20, TEXT, true);
        title.setLetterSpacing(0.08f);
        head.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        TextView version = text("PREMIUM  •  2.0", 10, MINT, true);
        version.setPadding(dp(10), dp(7), dp(10), dp(7));
        version.setBackground(round(PANEL_2, 30, 0, Color.TRANSPARENT));
        head.addView(version);
        content.addView(head);
        TextView sub = text("CHẨN ĐOÁN THIẾT BỊ  /  OFFLINE", 10, MUTED, true);
        sub.setLetterSpacing(0.13f);
        addGap(content, 18);
        content.addView(sub);

        addGap(content, 18);
        LinearLayout hero = panel();
        hero.setOrientation(LinearLayout.VERTICAL);
        LinearLayout heroTop = new LinearLayout(this);
        heroTop.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout scoreCol = new LinearLayout(this);
        scoreCol.setOrientation(LinearLayout.VERTICAL);
        scoreValue = text("--", 42, MINT, true);
        scoreValue.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        scoreCol.addView(text("CHỈ SỐ TÌNH TRẠNG", 10, MUTED, true));
        scoreCol.addView(scoreValue);
        scoreNote = text("Đang kiểm tra dữ liệu hệ thống…", 12, MUTED, false);
        scoreCol.addView(scoreNote);
        heroTop.addView(scoreCol, new LinearLayout.LayoutParams(0, -2, 1));
        TextView shield = text("✚", 42, MINT, true);
        shield.setGravity(Gravity.CENTER);
        shield.setBackground(round(Color.rgb(23, 62, 57), 60, 0, Color.TRANSPARENT));
        LinearLayout.LayoutParams shieldLp = new LinearLayout.LayoutParams(dp(76), dp(76));
        shieldLp.leftMargin = dp(12);
        heroTop.addView(shield, shieldLp);
        hero.addView(heroTop);
        addGap(hero, 14);
        healthBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        healthBar.setMax(100);
        healthBar.setProgressTintList(android.content.res.ColorStateList.valueOf(MINT));
        healthBar.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(42, 55, 66)));
        hero.addView(healthBar, new LinearLayout.LayoutParams(-1, dp(6)));
        addGap(hero, 12);
        hero.addView(text("Đánh giá ước tính từ thông số hệ thống. Không thay thế kiểm định phần cứng chuyên dụng.", 11, MUTED, false));
        content.addView(hero);

        addGap(content, 14);
        Button scan = button("QUÉT NHANH THIẾT BỊ", MINT, BG);
        scan.setOnClickListener(v -> {
            refreshSnapshot();
            Toast.makeText(this, "Đã cập nhật dữ liệu hệ thống", Toast.LENGTH_SHORT).show();
        });
        content.addView(scan, new LinearLayout.LayoutParams(-1, dp(50)));

        addGap(content, 22);
        content.addView(section("THIẾT BỊ CỦA BẠN", "Thông số đọc trực tiếp từ Android"));
        addGap(content, 10);
        LinearLayout info = panel();
        info.setOrientation(LinearLayout.VERTICAL);
        deviceSummary = text("Đang đọc thiết bị…", 13, TEXT, false);
        info.addView(deviceSummary);
        addDivider(info);
        LinearLayout metrics = new LinearLayout(this);
        metrics.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout memCol = metricColumn("RAM KHẢ DỤNG", "--");
        LinearLayout storeCol = metricColumn("BỘ NHỚ TRỐNG", "--");
        LinearLayout batCol = metricColumn("PIN", "--");
        ramValue = (TextView) memCol.getChildAt(1);
        storageValue = (TextView) storeCol.getChildAt(1);
        batteryValue = (TextView) batCol.getChildAt(1);
        metrics.addView(memCol, new LinearLayout.LayoutParams(0, -2, 1));
        metrics.addView(storeCol, new LinearLayout.LayoutParams(0, -2, 1));
        metrics.addView(batCol, new LinearLayout.LayoutParams(0, -2, 1));
        info.addView(metrics);
        addDivider(info);
        thermalValue = text("Nhiệt độ: --", 12, MUTED, false);
        info.addView(thermalValue);
        addDivider(info);
        info.addView(text("ĐÁNH GIÁ & GỢI Ý", 10, MINT, true));
        addGap(info, 6);
        adviceValue = text("Đang tổng hợp…", 12, TEXT, false);
        info.addView(adviceValue);
        content.addView(info);

        addGap(content, 22);
        content.addView(section("KIỂM TRA PHẦN CỨNG", "Một số bài test cần thao tác trực tiếp"));
        addGap(content, 10);
        addActionRow(content,
                action("Màn hình", "Điểm chết • màu sắc", "▣", () -> startActivity(new Intent(this, ScreenTestActivity.class))),
                action("Cảm ứng", "Đa điểm • độ phủ", "✥", () -> startActivity(new Intent(this, TouchTestActivity.class))));
        addActionRow(content,
                action("Loa & micro", "Kênh trái/phải • thu âm", "♫", () -> startActivity(new Intent(this, AudioTestActivity.class))),
                action("Cảm biến", "Gia tốc • tiệm cận…", "⌁", () -> startActivity(new Intent(this, SensorTestActivity.class))));
        addActionRow(content,
                action("Đèn flash", "Kiểm tra đèn LED", "✦", () -> startActivity(new Intent(this, FlashlightTestActivity.class))),
                action("Độ rung", "Rung ngắn an toàn", "〰", this::vibrationTest));
        addActionRow(content,
                action("GPU / FPS", "Đo khung hình Canvas", "◉", () -> startActivity(new Intent(this, GpuTestActivity.class))),
                action("CPU", "Benchmark 2 giây", "⌘", this::runCpuBenchmark));
        addActionRow(content,
                action("Camera", "Mở camera hệ thống", "▧", this::openCameraTest),
                action("Cài đặt pin", "Mở trang pin Android", "▱", this::openBatterySettings));

        addGap(content, 22);
        content.addView(section("BẢO TRÌ AN TOÀN", "Không can thiệp tiến trình hay dữ liệu cá nhân"));
        addGap(content, 10);
        LinearLayout maintenance = panel();
        maintenance.setOrientation(LinearLayout.VERTICAL);
        addUtility(maintenance, "Dọn cache Phone Doctor", "Chỉ xóa tệp tạm do ứng dụng này tạo ra", "DỌN", this::clearOwnCache);
        addDivider(maintenance);
        addUtility(maintenance, "Mở quản lý bộ nhớ Android", "Tự chọn ứng dụng / tệp cần xử lý", "MỞ", this::openStorageSettings);
        addDivider(maintenance);
        addUtility(maintenance, "Xuất báo cáo kiểm tra", "Chia sẻ bản tóm tắt dưới dạng văn bản", "XUẤT", this::shareReport);
        content.addView(maintenance);

        addGap(content, 18);
        TextView privacy = text("QUYỀN RIÊNG TƯ\nỨng dụng chạy ngoại tuyến, không gửi dữ liệu đi đâu. Không đọc IMEI, danh bạ, vị trí, ảnh hoặc tin nhắn. Micro / camera chỉ dùng trong bài test bạn tự mở và cấp quyền.", 11, MUTED, false);
        privacy.setPadding(dp(14), dp(13), dp(14), dp(13));
        privacy.setBackground(round(PANEL, 16, 0, Color.TRANSPARENT));
        content.addView(privacy);
        addGap(content, 8);
        TextView foot = text("Phone Doctor 2.0  •  Kết quả phụ thuộc phần cứng và phiên bản Android", 10, MUTED, false);
        foot.setGravity(Gravity.CENTER);
        content.addView(foot);
    }

    private void refreshSnapshot() {
        snapshot = DeviceSnapshot.read(this);
        scoreValue.setText(String.valueOf(snapshot.score));
        healthBar.setProgress(snapshot.score);
        scoreNote.setText(snapshot.summary);
        deviceSummary.setText(snapshot.device + "\nAndroid " + snapshot.android + "  •  " + snapshot.cores + " lõi CPU khả dụng\n" + snapshot.screen + "  •  " + snapshot.abi + "\nRAM tổng " + snapshot.ram + "  •  Bộ nhớ trong " + snapshot.storage + "\n" + snapshot.sensors + " cảm biến được hệ thống liệt kê  •  " + snapshot.network);
        ramValue.setText(snapshot.ramFree);
        storageValue.setText(snapshot.storageFree);
        batteryValue.setText(snapshot.batteryLevel);
        thermalValue.setText("Pin: " + snapshot.batteryDetails + "    •    Nhiệt hệ thống: " + snapshot.thermal);
        adviceValue.setText(snapshot.advice);
    }

    private void runCpuBenchmark() {
        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Đang đo CPU")
                .setMessage("Đang chạy phép thử số nguyên trong 2 giây. Giữ ứng dụng ở màn hình này nhé.")
                .setCancelable(false).create();
        dialog.show();
        worker.execute(() -> {
            long end = System.nanoTime() + 2_000_000_000L;
            int n = 2, primes = 0;
            while (System.nanoTime() < end) {
                boolean prime = true;
                for (int d = 2; d * d <= n; d++) if (n % d == 0) { prime = false; break; }
                if (prime) primes++;
                n++;
            }
            final int result = primes;
            handler.post(() -> {
                if (isFinishing()) return;
                dialog.dismiss();
                new AlertDialog.Builder(this).setTitle("Kết quả CPU")
                        .setMessage("Đã kiểm tra " + result + " số nguyên tố trong 2 giây.\n\nĐây là phép thử nội bộ để so sánh chính thiết bị qua các lần chạy, không phải điểm AnTuTu và không thể so trực tiếp giữa các máy.")
                        .setPositiveButton("Đóng", null).show();
            });
        });
    }

    private void vibrationTest() {
        Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        if (vibrator == null || !vibrator.hasVibrator()) {
            toast("Thiết bị không báo có mô-tơ rung");
            return;
        }
        if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(VibrationEffect.createOneShot(280, VibrationEffect.DEFAULT_AMPLITUDE));
        else vibrator.vibrate(280);
        toast("Đã gửi lệnh rung 280 ms");
    }

    private void clearOwnCache() {
        long before = folderSize(getCacheDir());
        long extBefore = getExternalCacheDir() == null ? 0 : folderSize(getExternalCacheDir());
        worker.execute(() -> {
            deleteChildren(getCacheDir());
            if (getExternalCacheDir() != null) deleteChildren(getExternalCacheDir());
            long freed = before + extBefore;
            handler.post(() -> new AlertDialog.Builder(this).setTitle("Đã dọn cache ứng dụng")
                    .setMessage("Đã giải phóng khoảng " + formatBytes(freed) + ".\n\nChỉ cache của Phone Doctor được xóa. Ảnh, video, tài liệu, dữ liệu ứng dụng khác và RAM không bị đụng tới.")
                    .setPositiveButton("OK", (d, w) -> refreshSnapshot()).show());
        });
    }

    private void openStorageSettings() {
        try { startActivity(new Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)); }
        catch (Exception e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
    }

    private void openBatterySettings() {
        try { startActivity(new Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)); }
        catch (Exception e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
    }

    private void openCameraTest() {
        // Open the system camera UI; this app does not capture or save an image.
        try {
            Intent camera = new Intent(android.provider.MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
            if (camera.resolveActivity(getPackageManager()) != null) startActivity(camera);
            else toast("Thiết bị không có ứng dụng camera mặc định.");
        } catch (Exception e) { toast("Không mở được camera hệ thống."); }
    }

    private void shareReport() {
        if (snapshot == null) refreshSnapshot();
        String report = "PHONE DOCTOR 2.0 - BÁO CÁO\n" +
                "Thời điểm: " + new java.util.Date() + "\n" +
                "Thiết bị: " + snapshot.device + "\nAndroid: " + snapshot.android + "\nCPU: " + snapshot.cores + " lõi khả dụng / " + snapshot.abi +
                "\nMàn hình: " + snapshot.screen + "\nRAM: " + snapshot.ram + " (trống " + snapshot.ramFree + ")" +
                "\nLưu trữ: " + snapshot.storage + " (trống " + snapshot.storageFree + ")" +
                "\nPin: " + snapshot.batteryLevel + " / " + snapshot.batteryDetails +
                "\nNhiệt hệ thống: " + snapshot.thermal + "\nCảm biến: " + snapshot.sensors +
                "\nKết nối: " + snapshot.network + "\nChỉ số ước tính: " + snapshot.score + "/100\nGợi ý: " + snapshot.advice + "\n\n" +
                "Lưu ý: chỉ số không phải chẩn đoán chuyên nghiệp. Test điểm chết/cảm ứng/loa/mic/đèn flash cần kiểm tra trực tiếp.";
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_SUBJECT, "Báo cáo Phone Doctor");
        send.putExtra(Intent.EXTRA_TEXT, report);
        startActivity(Intent.createChooser(send, "Chia sẻ báo cáo"));
    }

    private static long folderSize(File f) {
        if (f == null || !f.exists()) return 0;
        if (f.isFile()) return f.length();
        long sum = 0;
        File[] files = f.listFiles();
        if (files != null) for (File child : files) sum += folderSize(child);
        return sum;
    }
    private static void deleteChildren(File dir) {
        if (dir == null || !dir.isDirectory()) return;
        File[] children = dir.listFiles();
        if (children != null) for (File f : children) deleteRecursively(f);
    }
    private static void deleteRecursively(File f) {
        if (f.isDirectory()) {
            File[] children = f.listFiles();
            if (children != null) for (File c : children) deleteRecursively(c);
        }
        // Only called for this app's private cache directories.
        try { f.delete(); } catch (Exception ignored) {}
    }

    private interface Click { void run(); }
    private static class ActionItem { String title, desc, icon; Click click; ActionItem(String t, String d, String i, Click c) { title=t;desc=d;icon=i;click=c; } }
    private ActionItem action(String t, String d, String i, Click c) { return new ActionItem(t,d,i,c); }
    private void addActionRow(LinearLayout parent, ActionItem a, ActionItem b) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        addActionCard(row, a);
        View spacer = new View(this); row.addView(spacer, new LinearLayout.LayoutParams(dp(10), 1));
        addActionCard(row, b);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(10); parent.addView(row, lp);
    }
    private void addActionCard(LinearLayout row, ActionItem item) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(13), dp(14), dp(12), dp(13));
        card.setBackground(round(PANEL, 18, 1, Color.rgb(33, 48, 62)));
        card.setClickable(true); card.setFocusable(true);
        TextView icon = text(item.icon, 22, MINT, true);
        card.addView(icon);
        addGap(card, 10);
        card.addView(text(item.title, 14, TEXT, true));
        addGap(card, 3);
        card.addView(text(item.desc, 10, MUTED, false));
        card.setOnClickListener(v -> item.click.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(112), 1);
        row.addView(card, lp);
    }
    private void addUtility(LinearLayout parent, String title, String desc, String action, Click click) {
        LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(0, dp(11), 0, dp(11));
        LinearLayout col = new LinearLayout(this); col.setOrientation(LinearLayout.VERTICAL);
        col.addView(text(title, 13, TEXT, true)); addGap(col, 3); col.addView(text(desc, 10, MUTED, false));
        row.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
        TextView btn = text(action + "  ›", 11, MINT, true); btn.setPadding(dp(12), dp(9), dp(4), dp(9));
        row.addView(btn); row.setOnClickListener(v -> click.run()); parent.addView(row);
    }
    private LinearLayout metricColumn(String label, String value) {
        LinearLayout col = new LinearLayout(this); col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(2), dp(10), dp(2), dp(4));
        col.addView(text(label, 9, MUTED, true));
        col.addView(text(value, 15, TEXT, true));
        return col;
    }
    private TextView section(String title, String desc) {
        TextView result = text(title + "\n" + desc, 13, TEXT, true);
        result.setLineSpacing(dp(3), 1f);
        return result;
    }
    private LinearLayout panel() { LinearLayout l = new LinearLayout(this); l.setPadding(dp(16), dp(16), dp(16), dp(16)); l.setBackground(round(PANEL, 20, 1, Color.rgb(34, 49, 62))); return l; }
    private void addDivider(LinearLayout parent) { View v = new View(this); v.setBackgroundColor(Color.rgb(39, 53, 66)); LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(1)); lp.topMargin=dp(10); lp.bottomMargin=dp(8); parent.addView(v, lp); }
    private void addGap(LinearLayout parent, int height) { View v = new View(this); parent.addView(v, new LinearLayout.LayoutParams(1, dp(height))); }
    private TextView text(String s, int size, int color, boolean bold) { TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); if (bold) t.setTypeface(Typeface.create("sans-serif", Typeface.BOLD)); return t; }
    private Button button(String label, int bg, int fg) { Button b = new Button(this); b.setText(label); b.setTextSize(12); b.setTextColor(fg); b.setTypeface(Typeface.DEFAULT, Typeface.BOLD); b.setAllCaps(false); b.setBackground(round(bg, 16, 0, Color.TRANSPARENT)); return b; }
    private GradientDrawable round(int color, int radius, int stroke, int strokeColor) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); if (stroke > 0) d.setStroke(dp(stroke), strokeColor); return d; }
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
    private static String formatBytes(long n) { if (n < 1024) return n + " B"; if (n < 1024L*1024) return String.format(Locale.US, "%.1f KB", n/1024d); if (n < 1024L*1024*1024) return String.format(Locale.US, "%.1f MB", n/(1024d*1024)); return String.format(Locale.US, "%.2f GB", n/(1024d*1024*1024)); }

    private static class DeviceSnapshot {
        String device, android, abi, screen, ram, ramFree, storage, storageFree, batteryLevel, batteryDetails, thermal, network;
        int cores, sensors, score;
        String summary, advice;
        static DeviceSnapshot read(Activity a) {
            DeviceSnapshot s = new DeviceSnapshot();
            s.device = Build.MANUFACTURER + " " + Build.MODEL;
            s.android = Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")";
            s.abi = Build.SUPPORTED_ABIS != null && Build.SUPPORTED_ABIS.length > 0 ? Build.SUPPORTED_ABIS[0] : "Không rõ ABI";
            s.cores = Runtime.getRuntime().availableProcessors();
            DisplayMetrics dm = new DisplayMetrics();
            try { Display d = ((WindowManager)a.getSystemService(WINDOW_SERVICE)).getDefaultDisplay(); d.getRealMetrics(dm); s.screen = dm.widthPixels + " × " + dm.heightPixels + " px / " + Math.round(d.getRefreshRate()) + " Hz"; }
            catch (Exception e) { s.screen = "Không đọc được màn hình"; }
            ActivityManager am = (ActivityManager)a.getSystemService(ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo(); am.getMemoryInfo(mi);
            s.ram = formatBytes(mi.totalMem); s.ramFree = formatBytes(mi.availMem);
            StatFs fs = new StatFs(Environment.getDataDirectory().getAbsolutePath());
            long total = fs.getTotalBytes(), free = fs.getAvailableBytes();
            s.storage = formatBytes(total); s.storageFree = formatBytes(free);
            int level = -1, scale = 100, temp = -1, voltage = -1, health = 0;
            Intent bi = a.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (bi != null) { level = bi.getIntExtra(BatteryManager.EXTRA_LEVEL, -1); scale = bi.getIntExtra(BatteryManager.EXTRA_SCALE, 100); temp = bi.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1); voltage = bi.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1); health = bi.getIntExtra(BatteryManager.EXTRA_HEALTH, 0); }
            int pct = level >= 0 && scale > 0 ? Math.round(level * 100f / scale) : -1;
            s.batteryLevel = pct >= 0 ? pct + "%" : "Không rõ";
            int status = bi == null ? -1 : bi.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            String chargeState = status == BatteryManager.BATTERY_STATUS_CHARGING ? "đang sạc" : status == BatteryManager.BATTERY_STATUS_FULL ? "đầy pin" : status == BatteryManager.BATTERY_STATUS_DISCHARGING ? "đang dùng" : "trạng thái chưa rõ";
            s.batteryDetails = chargeState + " / " + (temp >= 0 ? String.format(Locale.US, "%.1f°C", temp/10f) : "nhiệt độ N/A") + (voltage > 0 ? " / " + voltage + " mV" : "") + " / " + healthName(health);
            PowerManager pm = (PowerManager)a.getSystemService(POWER_SERVICE);
            int thermalStatus = -1;
            if (Build.VERSION.SDK_INT >= 29 && pm != null) {
                thermalStatus = pm.getCurrentThermalStatus();
                String[] names = {"Bình thường", "Nhẹ", "Trung bình", "Nặng", "Nghiêm trọng", "Khẩn cấp", "Tắt máy"};
                s.thermal = thermalStatus >= 0 && thermalStatus < names.length ? names[thermalStatus] : "Không rõ";
            } else s.thermal = "Android không cung cấp";
            ConnectivityManager cm = (ConnectivityManager)a.getSystemService(CONNECTIVITY_SERVICE);
            Network active = cm == null ? null : cm.getActiveNetwork();
            NetworkCapabilities nc = active == null || cm == null ? null : cm.getNetworkCapabilities(active);
            if (nc == null) s.network = "Ngoại tuyến";
            else if (nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) s.network = "Wi-Fi";
            else if (nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) s.network = "Dữ liệu di động";
            else if (nc.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) s.network = "Ethernet";
            else s.network = "Đang kết nối";
            s.sensors = ((android.hardware.SensorManager)a.getSystemService(SENSOR_SERVICE)).getSensorList(android.hardware.Sensor.TYPE_ALL).size();
            int storageFreePct = (int)(free * 100d / Math.max(1,total));
            int ramFreePct = (int)(mi.availMem * 100d / Math.max(1,mi.totalMem));
            int points = 100;
            if (storageFreePct < 8) points -= 18;
            if (ramFreePct < 8) points -= 10;
            if (temp > 450) points -= 12;
            if (health == BatteryManager.BATTERY_HEALTH_OVERHEAT || health == BatteryManager.BATTERY_HEALTH_DEAD) points -= 18;
            if (thermalStatus >= 4) points -= 18; else if (thermalStatus == 3) points -= 10;
            s.score = Math.max(0, points);
            s.summary = s.score >= 90 ? "Các chỉ số hệ thống đang ổn định" : s.score >= 75 ? "Có vài chỉ số nên theo dõi" : "Nên kiểm tra thêm bộ nhớ, nhiệt hoặc pin";
            StringBuilder tips = new StringBuilder();
            if (storageFreePct < 15) tips.append("• Bộ nhớ gần đầy: mở Quản lý bộ nhớ và tự chọn tệp không cần thiết để xóa.\n");
            if (ramFreePct < 10) tips.append("• RAM khả dụng thấp tại thời điểm quét: đóng bớt tác vụ nặng và kiểm tra lại sau vài phút.\n");
            if (temp > 450) tips.append("• Pin đang nóng: ngừng game / sạc nhanh, để máy nơi thoáng mát; không cho vào tủ lạnh.\n");
            if (health == BatteryManager.BATTERY_HEALTH_OVERHEAT || health == BatteryManager.BATTERY_HEALTH_DEAD) tips.append("• Android báo trạng thái pin bất thường: kiểm tra pin tại trung tâm kỹ thuật.\n");
            if (thermalStatus >= 4) tips.append("• Hệ thống báo nhiệt rất cao: dừng tác vụ nặng và để máy nguội tự nhiên.\n");
            else if (thermalStatus == 3) tips.append("• Máy đang có cảnh báo nhiệt mức nặng: tạm nghỉ tác vụ nặng.\n");
            if (tips.length() == 0) tips.append("Chưa thấy cảnh báo từ các chỉ số hệ thống có thể đọc. Đây chưa phải kết luận máy hoàn hảo; hãy chạy thêm các bài test màn hình, cảm ứng, âm thanh và cảm biến.");
            s.advice = tips.toString().trim();
            return s;
        }
        static String healthName(int h) {
            switch (h) {
                case BatteryManager.BATTERY_HEALTH_GOOD: return "Pin báo tốt";
                case BatteryManager.BATTERY_HEALTH_OVERHEAT: return "Pin quá nhiệt";
                case BatteryManager.BATTERY_HEALTH_DEAD: return "Pin báo lỗi";
                case BatteryManager.BATTERY_HEALTH_COLD: return "Pin quá lạnh";
                case BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE: return "Pin báo lỗi không rõ";
                default: return "Sức khỏe pin chưa rõ";
            }
        }
    }
}
