package com.phonedoctor.premium;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class FlashlightTestActivity extends Activity {
    private static final int CAMERA_REQ=41;
    private CameraManager cameraManager;
    private String cameraId;
    private boolean enabled=false;
    private TextView status;
    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.rgb(9,14,21));getWindow().setNavigationBarColor(Color.rgb(9,14,21));
        cameraManager=(CameraManager)getSystemService(CAMERA_SERVICE); findFlash();
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setGravity(Gravity.CENTER);root.setPadding(26,26,26,26);root.setBackgroundColor(Color.rgb(9,14,21));
        TextView title=txt("KIỂM TRA ĐÈN FLASH",22,Color.WHITE,true);root.addView(title);
        TextView desc=txt("Ứng dụng chỉ bật/tắt đèn LED, không chụp ảnh hoặc quay video. Hãy hướng đèn ra xa mắt.",13,0xFF91A2B0,false);desc.setGravity(Gravity.CENTER);desc.setPadding(0,12,0,24);root.addView(desc);
        Button toggle=new Button(this);toggle.setText("BẬT / TẮT ĐÈN FLASH");toggle.setAllCaps(false);toggle.setTextSize(14);toggle.setTextColor(Color.rgb(9,14,21));toggle.setBackground(round(0xFF76E6C4,18));root.addView(toggle,new LinearLayout.LayoutParams(-1,58));toggle.setOnClickListener(v->toggle());
        status=txt(cameraId==null?"Không tìm thấy đèn flash được hệ thống hỗ trợ.":"Đèn đang tắt. Bấm nút để thử.",14,Color.WHITE,true);status.setGravity(Gravity.CENTER);status.setPadding(10,22,10,10);root.addView(status);
        setContentView(root);
    }
    private void findFlash(){try{for(String id:cameraManager.getCameraIdList()){CameraCharacteristics c=cameraManager.getCameraCharacteristics(id);Boolean flash=c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);if(Boolean.TRUE.equals(flash)){cameraId=id;break;}}}catch(Exception ignored){cameraId=null;}}
    private void toggle(){
        if(cameraId==null){status.setText("Thiết bị không có đèn flash hoặc Android không cho truy cập.");return;}
        if(checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){new AlertDialog.Builder(this).setTitle("Cấp quyền camera để dùng đèn flash?").setMessage("Quyền này chỉ được dùng để bật/tắt đèn LED. Ứng dụng không chụp ảnh hay quay video.").setNegativeButton("Hủy",null).setPositiveButton("Cho phép",(d,w)->requestPermissions(new String[]{Manifest.permission.CAMERA},CAMERA_REQ)).show();return;}
        setTorch(!enabled);
    }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==CAMERA_REQ && g.length>0 && g[0]==PackageManager.PERMISSION_GRANTED)status.setText("Đã cấp quyền. Bấm nút lần nữa để bật đèn.");}
    private void setTorch(boolean on){try{cameraManager.setTorchMode(cameraId,on);enabled=on;status.setText(on?"ĐÈN ĐANG BẬT  •  Bấm nút để tắt":"Đèn đang tắt");}catch(Exception e){enabled=false;status.setText("Không thể điều khiển đèn: "+e.getClass().getSimpleName());}}
    @Override protected void onPause(){if(enabled)setTorch(false);super.onPause();}
    private TextView txt(String s,int z,int c,boolean b){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);if(b)t.setTypeface(null,1);return t;}
    private GradientDrawable round(int c,int r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(r*getResources().getDisplayMetrics().density);return d;}
}
