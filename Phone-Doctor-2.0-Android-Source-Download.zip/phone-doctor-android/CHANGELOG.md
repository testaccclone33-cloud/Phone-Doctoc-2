# Changelog

## 2.0.0
- Chuyển sang ứng dụng Android native.
- Dashboard thiết bị, tình trạng hệ thống ước tính và báo cáo chia sẻ.
- Test màn hình, cảm ứng đa điểm, loa stereo, micro, cảm biến, đèn flash, rung, camera hệ thống, CPU và FPS Canvas.
- Dọn cache riêng của ứng dụng và mở cài đặt bộ nhớ / pin Android.
- Không có quyền Internet và không dùng dịch vụ phân tích.
